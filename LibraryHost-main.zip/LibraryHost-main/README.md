1) Satrt The Backend server by going to Backend Folder in LIB and run nodemon (Will run in port 8000)
2) To start react server go to FE folder and run "npm run dev" it will run in port 5173
3) The SQL commands and credientals are as per my MySQL DB 
